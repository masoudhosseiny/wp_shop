<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive.
 *
 * Override this template by copying it to yourtheme/woocommerce/archive-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
* @version     5.0.0
 
 */



if (!defined('ABSPATH')) { exit; } // Exit if accessed directly

global $woocommerce;

$cart_url = $woocommerce->cart->get_cart_url();
get_header('shop'); ?>



<div class="container">
<?php 
   //global  $woocommerce;
  
?>
<style type="text/css">#sidebar { display: none; } .woocommerce-pagination { display: none; }</style>



	<?php

		/**
		 * woocommerce_before_main_content hook
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */

		do_action('woocommerce_before_main_content');

	?>



		<?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>


			<div class="archive_header_left">
				<h1 class="page-title"><?php woocommerce_page_title(); ?></h1>
				<?php do_action( 'woocommerce_before_shop_loop' ); ?>
			</div>



		<?php endif; ?>



		<?php do_action( 'woocommerce_archive_description' ); ?>



		

		<?php if ( have_posts() ) : ?>



			<div style="float: right;" class="archive_header_right">

			<?php

				/**
				 * woocommerce_before_shop_loop hook
				 *
				 * @hooked woocommerce_result_count - 20
				 * @hooked woocommerce_catalog_ordering - 30
				 */

				do_action( 'woocommerce_before_shop_loop' );

			?>

			</div>
			<div class="clear"></div>
		</div>

</div>
</div>


				
				<div id="home_cont">
					
					<div id="stalac_cont">

			<?php woocommerce_product_loop_start(); ?>



				<?php woocommerce_product_subcategories(); ?>

				<?php global $x; ?>

				<?php $x = 0;

				global $wp_query;
				
				if ($_REQUEST['orderby'] == 'price') {
					$args = array_merge( $wp_query->query, array( 'posts_per_page' => -1, 'orderby' => 'meta_value_num', 'order' => 'asc', 'meta_key' => '_price' ) );
				} elseif ($_REQUEST['orderby'] == 'price-desc') {
					$args = array_merge( $wp_query->query, array( 'posts_per_page' => -1, 'orderby' => 'meta_value_num', 'order' => 'desc', 'meta_key' => '_price' ) );
				} else {
					$args = array_merge( $wp_query->query, array( 'posts_per_page' => -1 ) );
				}

				query_posts( $args );     
				
				?>
				<?php while ( have_posts() ) : the_post(); ?>

						
							<div class="item stalac_box">
								<span class="stalac_box_img">
									<?php if(get_post_meta( get_the_ID(), 'page_featured_type', true ) == 'youtube') { ?>
										<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo get_post_meta( get_the_ID(), 'page_video_id', true ); ?>" frameborder="0" allowfullscreen></iframe>
									<?php } elseif(get_post_meta( get_the_ID(), 'page_featured_type', true ) == 'vimeo') { ?>
										<iframe src="https://player.vimeo.com/video/<?php echo get_post_meta( get_the_ID(), 'page_video_id', true ); ?>?title=0&amp;byline=0&amp;portrait=0&amp;color=3399ff" width="500" height="338" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
									<?php } else { ?>
										<?php //the_post_thumbnail('stalac-image'); ?>
										<?php the_post_thumbnail('large'); ?>
										<!--<a class="stalac_box_hover" href="<?php the_permalink(); ?>">-->
										<div class="stalac_box_hover">
											<span class="stalac_box_hover_inside_tbl">
												<span class="stalac_box_hover_inside_row">
													<span class="stalac_box_hover_inside_cell">
														<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
														<!--<p><?php //echo ds_get_excerpt('160'); ?></p>-->
														<?php //woocommerce_get_template_part( 'content', 'product-home-inside' ); ?>
														<div class="hover_price">
														<?php
															//do_action( 'woocommerce_after_shop_loop_item_title' );
															$product = new WC_Product( get_the_ID() );
															$price = $product->price;
															 echo get_woocommerce_currency_symbol() . $price;

														?>
														<?php //echo get_post_meta(get_the_ID(), "price", true); ?>
														</div>
														<?php 
															$connector = '?';

															if (strpos($cart_url,'?') != false)
																$connector = '&';		
														?>		
														<p class="add_to_cart_hover"><a href="<?php echo $cart_url . $connector.'add-to-cart=' . get_the_ID(); ?>">ADD TO CART</a></p>								
													</span> <!-- //stalac_box_hover_inside_cell -->
												</span> <!-- //stalac_box_hover_inside_row -->
											</span> <!-- //stalac_box_hover_tbl -->
										</div> <!-- //stalac_box_hover -->
									<?php } ?>												
								</span> <!-- //stalac_box_img -->
								
										
										
										
							
								
								
								
							</div> <!-- //stalac_box -->                               				
				

				<?php endwhile; // end of the loop. ?>

			<?php woocommerce_product_loop_end(); ?>

					</div><!--//stalac_cont-->
					
				</div><!--//home_cont-->
		

			<?php

				/**

				 * woocommerce_after_shop_loop hook

				 *

				 * @hooked woocommerce_pagination - 10

				 */

				do_action( 'woocommerce_after_shop_loop' );

			?>



		<?php elseif ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) : ?>



			<?php woocommerce_get_template( 'loop/no-products-found.php' ); ?>



		<?php endif; ?>



	<?php

		/**

		 * woocommerce_after_main_content hook

		 *

		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)

		 */

		do_action('woocommerce_after_main_content');

	?>



	<?php

		/**

		 * woocommerce_sidebar hook

		 *

		 * @hooked woocommerce_get_sidebar - 10

		 */

		//do_action('woocommerce_sidebar');

	?>



<?php get_footer('shop'); ?>







<script type="text/javascript">

$(document).ready(

function($){

	$('.load_more_text a').click(function() {
		$(this).css('visibility','hidden');
		//alert('test');
	});

var curPage = 1;
var pagesNum = $("#max_pages_id").html();   // Number of pages	

if(pagesNum == 1)
	$('.load_more_text a').css('display','none');



  $('#posts_cont').infinitescroll({

 

    navSelector  : "div.load_more_text",            

		   // selector for the paged navigation (it will be hidden)

    nextSelector : "div.load_more_text a:first",    

		   // selector for the NEXT link (to page 2)

    itemSelector : "#posts_cont .home_small_box",
    behavior: "twitter",
    maxPage: <?php echo $max_pages; ?>    

		   // selector for all items you'll retrieve

  },function(arrayOfNewElems){

  

  $('#posts_cont').append('<div class="clear"></div>');


  		$('.load_more_text a').css('visibility','visible');

            curPage++;
//            alert(curPage + '**' + pagesNum);

            if(curPage == pagesNum) {

                //$(window).unbind('.infscr');
                $('.load_more_text a').css('display','none');

            } else {}  		  
  

      //$('.home_post_cont img').hover_caption();

 

     // optional callback when new content is successfully loaded in.

 

     // keyword `this` will refer to the new DOM content that was just added.

     // as of 1.5, `this` matches the element you called the plugin on (e.g. #content)

     //                   all the new elements that were found are passed in as an array

 

  });  

}  

);

</script>	